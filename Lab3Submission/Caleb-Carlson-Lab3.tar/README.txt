The order of which these scripts should be run:

1. CreateTables.sql (Creates tables, and view)
2. PopulateTables.sql (Populates tables with data)
3. Lab3Queries.sql (Executes queries for the numbered problems, and adds triggers)
4. ActivityScript.sql (Executes table modifications according to the Activity section)

The activities that could not be run due to referential integrity issues were:
  Activity 8 - the publisher id foreign key integrity check failed
